/**
 * @author chenqx
 * copyright 2015 Qcplay All Rights Reserved.
 */
/**
 * 提供富文本支持
 */

var RichTextParse 
