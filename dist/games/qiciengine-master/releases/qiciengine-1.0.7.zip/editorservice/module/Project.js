/**
 * @author wudm
 * copyright 2015 Qcplay All Rights Reserved.
 *
 * 工程管理相关
 */
var fs = require('fs-extra');
var path = require('path');

var clazz = function() {
};
clazz.prototype = {};
clazz.prototype.constructor = clazz;

var recentRecordNumber = 15;

// 创建一个工程
clazz.prototype.createProject = function(dir) {
    var errorRoutine = function(errorMsg, e) {
        if (e == null) {
            G.log.trace(errorMsg);
            return errorMsg;
        }
        else {
            G.log.error(errorMsg, e);
            return errorMsg + e;
        }
    };
    var fsEx = G.load('filesystem/FsExpand');

    // 必须是绝对路径
    if (!path.isAbsolute(dir))
        return errorRoutine('Project Directory must be a absolute path.');

    // 确保格式为目录方式
    dir = path.join(dir, '/');

    try {
        // 首先，如果存在目录，必须要空目录
        if (fs.existsSync(dir)) {
            // 确保是一个目录
            var stat = fs.statSync(dir);
            if (!stat || !stat.isDirectory())
                return errorRoutine('Not a directory.');

            // 确保是空目录
            var subFiles = fs.readdirSync(dir);
            for (var i = 0, len = subFiles.length; i < len; i++) {
                var fileName = subFiles[i];
                if (fsEx.isHidden(dir, fileName) ||
                    fsEx.skipWhenExplore(dir, fileName))
                    continue;

                // 非空目录
                return errorRoutine('Project Directory must be empty.');
            }
        }
        else {
            // 创建文件夹
            if (!fs.ensureDirSync(dir)) {
                return errorRoutine('Create directory failed.');
            }
        }

        // 切换目录
        var openResult = this.openProject(dir, true);
        if (openResult !== true) return openResult;

        // 尝试创建几个资源二级目录
        ['atlas', 'audio', 'excel', 'font', 'prefab', 'raw', 'sprite', 'scene', 'texture', 'action'].forEach(function(p) {
            var dirFullPath = path.join(dir, 'Assets', p);
            fs.ensureDirSync(dirFullPath);
        });

        return true;
    }
    catch (e) {
        return errorRoutine('throw exception.', e);
    }
};

// 打开一个工程
clazz.prototype.openProject = function(dir, createFlag) {
    var errorRoutine = function(errorMsg, e) {
        if (e == null) {
            G.log.trace(errorMsg);
            return errorMsg;
        }
        else {
            G.log.error(errorMsg, e);
            return errorMsg + e;
        }
    };

    // 必须是绝对路径
    if (!path.isAbsolute(dir))
        return errorRoutine('请输入工程的全路径。');

    // 确保格式为目录形态
    dir = path.join(dir, '/');

    try {
        // 简单的进行验证，确保路径存在
        if (!fs.existsSync(dir) ||
            !fs.statSync(dir).isDirectory())
            return errorRoutine('目标' + dir + '不是一个有效目录。');

        // 检查是否有 ProjectSetting/project.setting
        if (createFlag !== true &&
            (!fs.existsSync(path.join(dir, 'ProjectSetting')) ||
             !fs.existsSync(path.join(dir, 'ProjectSetting/project.setting'))))
            return errorRoutine('不存在project.setting，认为不是有效工程。');

        // 生成新工程的配置

        // 取消对之前目录的监听
        G.fsWatcher.forEach(function(fsWatcher) {
            fsWatcher.close();
        });

        G.gameRoot = dir;

        // 增加对新路径的监听
        G.watch.watchDir(G.gameRoot);

        M.USER_SCRIPTS.clearAllJsExt();

        // 切换静态监听
        M.COMMUNICATE.switchStatic();

        this.recordRecentOpen(dir);

        // 派发成功切换工程的事件
        G.emitter.emit('preSwitchProject');
        G.emitter.emit('switchProject');

        // 返回成功
        return true;
    }
    catch (e) {
        return errorRoutine('打开工程异常，异常原因：', e);
    }
};

// 发布工程到指定目录
clazz.prototype.publishTo = function(dstDir) {
    var buildify = require('buildify');
    var fsEx = G.load('filesystem/FsExpand');

    if (!G.gameRoot) return 'Invalid project';

    var publishContent = fs.readFileSync(G.editorRoot + 'Template/Publish.templet.html', 'utf8');
    var appCacheContent = fs.readFileSync(G.editorRoot + 'Template/ApplicationCache.templet.appcache', 'utf8');
    var publishParams = {
        gameRoot: G.gameRoot,
        outPath: dstDir,
        config: G.config.project,
        startGameTemplate: publishContent,
        appCacheTemplate: appCacheContent
    };
    G.emitter.emit('BeforePublish', publishParams);

    if (!G.config.scene.scene || !Object.keys(G.config.scene.scene).length)
        return 'Scene list is empty, please edit setting by menu Project/Settings';

    // G.log.trace('强行刷新下uuid2file。');
    G.gameFiles.refresh();

    // 收集插件列表
    var pluginScripts = M.PLUGIN_SCRIPTS.getPluginScripts();

    // 收集文件列表
    var userScripts = M.USER_SCRIPTS.getUserScripts();
    var ver = G.config.project.version;

    // 收集所有 lib 库
    var libScripts = [];
    var len;
    var scriptOutput = [];
    var targetLibPath, content;

    [ { scripts : pluginScripts, dir : path.dirname(M.PLUGIN_SCRIPTS.pluginsRoot) },
      { scripts : userScripts, dir : G.gameRoot } ]
      .forEach(function(scriptInfo) {
        var scripts = scriptInfo.scripts;
        var dir = scriptInfo.dir;

        len = scripts.length;
        while (len--) {
            if (/[\\/]lib[\\/]/.test(scripts[len])) {
                fs.ensureDirSync(path.join(dstDir, 'lib'));

                // 拷走文件，写路径，从目标中删除
                var scriptPath = scripts[len];
                targetLibPath = 'lib/' + path.basename(scriptPath);
                content = fs.readFileSync(path.join(dir, scriptPath));
                fs.writeFileSync(path.join(dstDir, targetLibPath), content);
                scriptOutput.push(targetLibPath);
                scripts.splice(len, 1);
            }
        }
    });

    // 校验 ver
    if (!ver || (!/^\d[\d\.]*\d$/.test(ver) && !/^\d$/.test(ver)))
        return 'Invalid version, please edit setting by menu Project/Settings';

    // 1. 写入所有user scripts到一个文件中
    var debugJSPath = 'js/game-scripts-debug-' + ver + '-' + G.uuid() + '.js';
    var miniJSPath = 'js/game-scripts-mini-' + ver + '.js';

    // 确保 js 目录存在
    fs.ensureDirSync(path.join(dstDir, 'js'));

    var packTemplatePath = 'Template/ScriptPackTemplate.js';

    // 生成混淆后的内容，写入文件
    buildify(G.gameRoot)
        .setDir(path.dirname(M.PLUGIN_SCRIPTS.pluginsRoot))
        .concat(pluginScripts)
        .setDir(G.gameRoot)
        .concat(userScripts)
        .setDir(G.editorRoot)
        .wrap(packTemplatePath, { version : ver })
        .setDir(dstDir)
        .save(debugJSPath)
        .uglify()
        .save(miniJSPath);

    // 补充 lib 目录
    scriptOutput.push(miniJSPath);

    // 2. 根据 Publish.templet.html 生成 StartGame.html
    // 读取模板文件
    // var content = fs.readFileSync(G.editorRoot + 'Template/Publish.templet.html', 'utf8');
    content = publishParams.startGameTemplate;

    // 替换脚本文件
    content = content.replace(/__PUBLISH_USER_SCRIPTS__/g, scriptOutput.join("',\n'./"));

    // 替换插件文件
    content = M.PLUGIN_SCRIPTS.genTemplateContent(content, true);

    // 加入用户脚本
    content = M.USER_SCRIPTS.genTemplateContent(content, true);

    // 写入目标文件
    fs.writeFileSync(path.join(dstDir, 'StartGame.html'), content);

    publishParams.startGameContent = content;

    // 3、判断是否生成 applicate cache 文件
    if (G.config.project.appCache)
    {
        // content = fs.readFileSync(G.editorRoot + 'Template/ApplicationCache.templet.appcache', 'utf8');
        content = publishParams.appCacheTemplate;
        content = content.replace(/__CACHE_VERSION__/g, M.util.formattedTime());
        content = content.replace(/{__ver__}/g, G.VERSION);
        content = content.replace(/__EXTERNAL_PLUGINS_SCRIPTS__/g,
                                  M.PLUGIN_SCRIPTS.printCacheExternalDependenceScripts(true));
        content = content.replace(/__PUBLISH_USER_SCRIPTS__/g, scriptOutput.join('\n'));
        content = M.USER_SCRIPTS.genCacheAssetsContent(content, true);
        fs.writeFileSync(path.join(dstDir, 'qici.appcache'), content);
        publishParams.appCacheContent = content;
    }

    // 4. 复制所有的 bin/ttf 到 Build 下

    // 遍历 Game/Assets 文件夹
    var explorePath = function(dir, targetDir) {
        if (!fs.existsSync(dir))
            return;
        var list = fs.readdirSync(dir);
        for (var i = 0, len = list.length; i < len; i++) {
            var subPath = list[i];
            var fullPath = path.join(dir, subPath);
            var stat = fs.statSync(fullPath);

            if (stat.isDirectory()) {
                // 如果是 xx@atlas 无视该路径
                if (subPath.indexOf('@atlas') >= 0) continue;
                explorePath(path.join(dir, subPath), path.join(targetDir, subPath));
            }
            else {
                var ext = path.extname(subPath).toLowerCase();
                var needExploreRaw = fsEx.needExploreRawFile(dir);
                if (!needExploreRaw &&
                    ['.bin', '.eot', '.ttf', '.svg', '.woff', '.ttc', '.mp3', '.ogg', '.js', '.css'].indexOf(ext) < 0) continue;

                // 拷贝本文件
                fs.ensureDirSync(targetDir);
                content = fs.readFileSync(fullPath);
                fs.writeFileSync(path.join(targetDir, subPath), content);
            }
        }
    };
    explorePath(path.join(G.gameRoot,'Assets'), path.join(dstDir, 'Assets'));

    var pluginAssets = M.PLUGIN_SCRIPTS.getPluginAssets();
    var len = pluginAssets.length;
    while (len--) {
        var relativePath = path.relative(M.PLUGIN_SCRIPTS.pluginsRoot, pluginAssets[len]);
        explorePath(pluginAssets[len], path.join(dstDir, 'Plugins', relativePath));
    }

    G.emitter.emit('AfterPublish', publishParams);
    return true;
};

// 获取最近打开的工程列表
clazz.prototype.getRecentOpen = function() {
    // 获取配置信息
    var conf;
    try {
        conf = fs.readJsonSync(path.join(G.editorRoot, 'project.setting'), { throws : false });
    }
    catch(e) {
        conf = null;
    }
    if (!conf) return [];
    if (!conf.recentOpen) return [];

    // 有信息，需逐个验证是否有效工程
    var recentOpen = conf.recentOpen;
    var i, len, p, valid;
    var modified;

    len = recentOpen.length;

    for (i = 0; i < len; i++) {
        p = recentOpen[i];
        valid = false;

        do
        {
            if (!p) break;
            try {
                if (!fs.existsSync(p) ||
                    !fs.statSync(p).isDirectory())
                    break;

                // 检查是否有 ProjectSetting/project.setting
                if (!fs.existsSync(path.join(p, 'ProjectSetting')) ||
                    !fs.existsSync(path.join(p, 'ProjectSetting/project.setting')))
                    break;

                valid = true;
            }
            catch (e) {}
        } while (false);

        if (!valid) {
            // 发现一个非法路径
            modified = true;
            recentOpen[i] = false;
        }
    }

    if (!modified) return recentOpen;

    // 整理后写入保存
    var ret = [];
    for (i = 0; i < len; i++) if (recentOpen[i]) ret.push(recentOpen[i]);
    M.PROJECT.setRecentOpen(ret);
    return ret;
};

// 设置最近打开的工程列表
clazz.prototype.setRecentOpen = function(recentOpen) {
    // 获取配置信息
    var conf;
    try {
        conf = fs.readJsonSync(path.join(G.editorRoot, 'project.setting'), { throws : false });
    }
    catch (e) {
        conf = null;
    }

    if (!conf) conf = {};
    conf.recentOpen = recentOpen;
    G.load('filesystem/FsExpand').writeJsonSync(path.join(G.editorRoot, 'project.setting'), conf);
};

// 记录最近打开的工程列表
clazz.prototype.recordRecentOpen = function(dir) {
    // 获取 project 设置
    var conf;
    try {
        conf = fs.readJsonSync(path.join(G.editorRoot, 'project.setting'), { throws : false });
    }
    catch (e) {
        conf = null;
    }
    var recentOpen;
    if (!conf) {
        conf = {};
        recentOpen = [];
    }
    else {
        recentOpen = conf.recentOpen;
        if (!recentOpen) recentOpen = [];
    }

    // 将新的 path 放在 list 的头部
    var index = recentOpen.indexOf(dir);


    if (index >= 0) {
        recentOpen.splice(index, 1);
        recentOpen.splice(0, 0, dir);
    }
    else {
        recentOpen.splice(0, 0, dir);
        if (recentOpen.length > recentRecordNumber)
            recentOpen = recentOpen.slice(0, recentRecordNumber);
    }

    // 回写保存
    conf.recentOpen = recentOpen;
    G.load('filesystem/FsExpand').writeJsonSync(path.join(G.editorRoot, 'project.setting'), conf);
};

// 生成game html文件
clazz.prototype.genGameHTML = function() {
    // G.log.trace('强行刷新下uuid2file。');
    G.gameFiles.refresh();

    M.COMMAND.dispatch('START_GAME_HTML', -1);
    M.COMMAND.dispatch('START_SCENE_HTML', -1);
    M.COMMAND.dispatch('PREVIEW_GAME_HTML', -1);
};

// file change 的时候异步生成游戏 html，该函数会聚合同一时间的请求为一次
clazz.prototype.prepareGenGameHTML = function() {
    // 尝试去获取整个文件夹的信息
    var self = M.PROJECT;
    var tick = new Date().getTime();

    if (tick - self._fileChangeMutex < 100 &&
        self._timeoutID)
        // 已经处于加载中，删除之前的 timer 延后生成
        clearTimeout(self._timeoutID);

    self._fileChangeMutex = tick;
    self._timeoutID = setTimeout(function() {
        delete self._fileChangeMutex;
        delete self._timeoutID;
        self.genGameHTML();
    }, 100);
};

// 保存项目配置
clazz.prototype.saveProjectSetting = function() {
    var f = G.load('filesystem/AutoConfigProject');
    f.writeProjectSetting(G.config.project);
}

// 定义模块
G.defineModule('PROJECT', clazz);
