/**
 * @author weism
 * @copyright 2015 Qcplay All Rights Reserved.
 *
 * 所有的文本
 */

/**
 * key为en，value为各种语言的翻译
 */
module.exports = {
    'QICI Engine/About QICI Engine...': {
        zh: '青瓷引擎/关于青瓷引擎...'
    },

    'QICI Engine/Check for Updates...': {
        zh: '青瓷引擎/检测更新...'
    },

    'QICI Engine/Help/zh/Manual...': {
        zh: '青瓷引擎/帮助/中文/手册...'
    },

    'QICI Engine/Help/zh/API...': {
        zh: '青瓷引擎/帮助/中文/API...'
    },

    'QICI Engine/Help/zh/Forum...': {
        zh: '青瓷引擎/帮助/中文/论坛...'
    },

    'QICI Engine/Help/en/Manual...': {
        zh: '青瓷引擎/帮助/英文/手册...'
    },

    'QICI Engine/Help/en/API...': {
        zh: '青瓷引擎/帮助/英文/API...'
    },

    'QICI Engine/Help/en/Forum...': {
        zh: '青瓷引擎/帮助/英文/论坛...'
    },

    'QICI Engine/Preference...': {
        zh: '青瓷引擎/偏好设置'
    },

    'Project/New Scene': {
        zh: '工程/新场景'
    },

    'Project/Save Scene': {
        zh: '工程/保存场景'
    },

    'Project/Reload Scene': {
        zh: '工程/刷新场景'
    },
    'Project/Open Recent': {
        zh: '工程/打开最近工程'
    },

    'Project/New Project': {
        zh: '工程/新建工程'
    },

    'Project/Open Project': {
        zh: '工程/打开工程'
    },

    'Project/Publish...': {
        zh: '工程/发布...'
    },

    'Project/Settings...': {
        zh: '工程/设置...'
    },

    'Edit/Undo': {
        zh: '编辑/回退'
    },

    'Edit/Redo': {
        zh: '编辑/重做'
    },

    'Edit/Cut': {
        zh: '编辑/剪切'
    },

    'Edit/Copy': {
        zh: '编辑/拷贝'
    },

    'Edit/Paste': {
        zh: '编辑/粘贴'
    },

    'Edit/Duplicate': {
        zh: '编辑/复制'
    },

    'Edit/Delete': {
        zh: '编辑/删除'
    },

    'Edit/Preview (WebGL)': {
        zh: '编辑/预览（WebGL）'
    },

    'Edit/Preview (Canvas)': {
        zh: '编辑/预览（Canvas）'
    },

    'Edit/Play': {
        zh: '编辑/运行'
    },

    'Edit/Play from Entry': {
        zh: '编辑/从入口场景运行'
    },

    'Edit/Apply to Prefab': {
        zh: '编辑/应用预制修改'
    },

    'GameObject/Empty Node': {
        zh: '游戏对象/空节点'
    },

    'GameObject/Image': {
        zh: '游戏对象/图片'
    },

    'GameObject/Sprite': {
        zh: '游戏对象/精灵'
    },

    'GameObject/Text': {
        zh: '游戏对象/文本'
    },

    'GameObject/Button': {
        zh: '游戏对象/按钮'
    },

    'GameObject/Toggle': {
        zh: '游戏对象/开关'
    },

    'GameObject/ScrollBar': {
        zh: '游戏对象/滚动条'
    },

    'GameObject/ScrollView': {
        zh: '游戏对象/滚动视图'
    },

    'GameObject/ProgressBar': {
        zh: '游戏对象/进度条'
    },

    'GameObject/Slider': {
        zh: '游戏对象/拉条'
    },

    'GameObject/Input Field': {
        zh: '游戏对象/输入框'
    },

    'GameObject/Sound': {
        zh: '游戏对象/音效'
    },

    'GameObject/Dom': {
        zh: '游戏对象/Dom节点'
    },

    'GameObject/UIRoot': {
        zh: '游戏对象/UIRoot'
    },

    'GameObject/Emitter': {
        zh: '游戏对象/粒子发射器'
    },

    'GameObject/Tilemap': {
        zh: '游戏对象/瓦片地图'
    },

    'GameObject/ParticleSystem': {
        zh: '游戏对象/粒子系统'
    },

    'GameObject/Graphics': {
        zh: '游戏对象/绘图'
    },

    'Empty Node': {
        zh: '空节点'
    },

    'Image': {
        zh: '图片'
    },

    'Sprite': {
        zh: '精灵'
    },

    'Text': {
        zh: '文本'
    },

    'Button': {
        zh: '按钮'
    },

    'Toggle': {
        zh: '开关'
    },

    'ScrollBar': {
        zh: '滚动条'
    },

    'ScrollView': {
        zh: '滚动视图'
    },

    'ProgressBar': {
        zh: '进度条'
    },

    'Slider': {
        zh: '拉条'
    },

    'Input Field': {
        zh: '输入框'
    },

    'Sound': {
        zh: '音效'
    },

    'Emitter': {
        zh: '粒子发射器'
    },

    'Graphics': {
        zh: '绘图'
    },

    'Tilemap': {
        zh: '瓦片地图'
    },

    'Tool/Frame Animation Editor': {
        zh: '工具/帧动作编辑器'
    },

    'Tool/Repack Texture Atlases': {
        zh: '工具/重打包图集'
    },

    'Tool/Import Assets': {
        zh: '工具/资源导入'
    },

    'Tool/Create WebFont': {
        zh: '工具/创建WebFont'
    },

    'Plugins/Plugin Manager': {
        zh: '插件/插件管理'
    },

    'Plugins/Plugin Store': {
        zh: '插件/插件商店'
    },

    'Plugins/Export Plugin': {
        zh: '插件/导出插件'
    },

    'Layout/Portrait': {
        zh: '布局/竖屏'
    },

    'Layout/Landscape': {
        zh: '布局/横屏'
    },

    'Language/中文': {
        zh: '语言/中文'
    },

    'Language/English': {
        zh: '语言/English'
    },

    'Quit running mode first': {
        zh: '请先退出运行模式'
    },

    'Stop editing prefab first': {
        zh: '请先结束预制编辑'
    },

    'Enter the new scene name': {
        zh: '请输入新场景名'
    },

    'Do you want to save the scene?': {
        zh: '是否保存当前场景？'
    },

    'Do you want to save the changes?': {
        zh: '是否保存改变？'
    },

    "Don't Save": {
        zh: '不保存'
    },

    'Save': {
        zh: '保存'
    },

    'Cancel' : {
        zh: '取消'
    },

    'Add Component': {
        zh: '添加脚本'
    },

    'Components': {
        zh: '脚本列表'
    },

    'Rebuild': {
        zh: '重新生成'
    },

    'Preference': {
        zh: '偏好设置'
    },

    'UI Atlas': {
        zh: '图集'
    },

    'Normal Texture': {
        zh: '普通贴图'
    },

    'Atlas': {
        zh: '图集'
    },

    'Frame Animation': {
        zh: '帧动画'
    },

    'DragonBone': {
        zh: '骨骼动画'
    },

    'DragonBone(Sampled)': {
        zh: '骨骼动画（采样）'
    },

    'Edit Frame Animation': {
        zh: '编辑帧动作'
    },

    'Sampled': {
        zh: '动作采样'
    },

    'DragonBone({0}) sampling is done': {
        zh: '骨骼（{0}）采样完成'
    },

    'Animations List': {
        zh: '动作列表'
    },

    'Name': {
        zh: '名称'
    },

    'Loop': {
        zh: '循环'
    },

    'Operation': {
        zh: '操作'
    },

    'Play': {
        zh: '运行'
    },

    'Pause': {
        zh: '暂停'
    },

    'Next Frame': {
        zh: '下一帧'
    },

    'Frames': {
        zh: '图片帧'
    },

    'Nine Patch Padding': {
        zh: '九宫格间距'
    },

    'Web Font': {
        zh: 'Web Font'
    },

    'Font Name': {
        en: 'Name',
        zh: '字体名称'
    },

    'Font URLs (One URL per line)': {
        zh: '字体地址（按行分开）'
    },

    'Font URLs are invalid': {
        zh: '字体的地址非法'
    },

    'Name must be digital or letter': {
        zh: '字体名称应该为数字或字母'
    },

    'Web font is saved to: ': {
        zh: '字体被保存到：'
    },

    'JavaScript Management': {
        zh: '脚本管理'
    },

    'Script': {
        zh: '脚本'
    },

    'Path': {
        zh: '路径'
    },

    'Entry': {
        zh: '入口脚本'
    },

    'Drop JavaScript File Here': {
        zh: '将JS文件拖拽到这里'
    },

    'Dependence List': {
        zh: '依赖列表'
    },

    'Add Filter': {
        zh: '添加着色器'
    },

    'Apply Prefab': {
        zh: '应用预制修改'
    },

    'Plugin Manager': {
        zh: '插件管理'
    },

    'Plugin List': {
        zh: '插件列表'
    },

    'Check for Updates': {
        zh: '检测更新'
    },

    'Version Info': {
        zh: '版本信息'
    },

    'Update': {
        zh: '更新'
    },

    'Project Settings': {
        zh: '工程设置'
    },

    'Project Name': {
        zh: '工程名'
    },

    'Game Name': {
        zh: '游戏名'
    },

    'Company': {
        zh: '公司名'
    },

    'Identifier': {
        zh: '标识符'
    },

    'Instance': {
        zh: '实例名'
    },

    'Version': {
        zh: '版本号'
    },

    'Width': {
        zh: '宽度'
    },

    'Orientation': {
        zh: '转向'
    },

    'Auto Rotate': {
        zh: '自动旋转'
    },

    'Portrait': {
        zh: '竖屏'
    },

    'Landscape': {
        zh: '横屏'
    },

    'Frame Rate': {
        zh: '帧率'
    },

    'Background Color': {
        zh: '背景色'
    },

    'Apply': {
        zh: '应用'
    },

    'Scene List': {
        zh: '场景列表'
    },

    'Reset Native Size': {
        zh: '重置大小'
    },

    'Generate Layers': {
        zh: '生成图层'
    },

    'Relayout': {
        zh: '重排'
    },

    'On': {
        zh: '开启'
    },

    'Frame Animation Editor': {
        zh: '帧动作编辑'
    },

    'File must be texture atlas': {
        zh: '文件必须为图集资源'
    },

    'DragonBone cannot be modified.': {
        zh: '骨骼动画不能被编辑'
    },

    "Drop Atlas File Here": {
        zh: '将图集文件拖到这里'
    },

    'Animation': {
        zh: '动作'
    },

    ' New ': {
        zh: ' 新建 '
    },

    ' Save ': {
        zh: ' 保存 '
    },

    ' Delete ': {
        zh: ' 删除 '
    },

    ' Back ': {
        zh: ' 返回 '
    },

    'Animation is empty': {
        zh: '动作帧信息不能为空'
    },

    'Animation\'s name is invalid': {
        zh: '动作名非法'
    },

    'Please create an animation': {
        zh: '请先创建一个动作'
    },

    'Import Assets': {
        zh: '资源导入'
    },

    'Import': {
        zh: '导入'
    },

    'Asset Name': {
        zh: '资源名称'
    },

    'Asset Path': {
        zh: '资源路径'
    },

    'Asset Type': {
        zh: '资源类型'
    },

    'List of Files': {
        zh: '文件列表'
    },

    'Drop files here': {
        zh: '拖拽文件到此处'
    },

    'Invalid asset': {
        zh: '未检测到资源'
    },

    'The asset name is invalid': {
        zh : '资源名称非法'
    },

    'Asset path is empty': {
        zh: '请选择保存路径'
    },

    'Files is empty': {
        zh: '导入文件列表为空'
    },

    'Import is done': {
        zh: '资源导入成功'
    },

    'Import error:': {
        zh: '资源导入失败：'
    },

    'Double click to select the folder': {
        zh: '双击选择文件夹'
    },

    'Set Curr To Start': {
        zh: '设置当前值为起始值'
    },

    'Set Curr To End': {
        zh: '设置当前值为结束值'
    },

    'Play/Stop': {
        zh: '运行/停止'
    },

    'Reset To Begin': {
        zh: '重置到起始值'
    },

    'Play/Stop Group': {
        zh: '运行组/停止组'
    },

    'Reset Group to Begin': {
        zh: '重置组到起始值'
    },

    'Stop editing frame animation?': {
        zh: '正在编辑帧动作，确定要退出吗？'
    },

    'Yes': {
        zh: '是'
    },

    'New Folder': {
        zh: '创建目录'
    },

    'Open in Local File Explorer': {
        zh: '在本地文件管理器中打开'
    },

    'Delete': {
        zh: '删除'
    },

    'Rename': {
        zh: '重命名'
    },

    'New JavaScript File': {
        zh: '创建JavaScript脚本'
    },

    'Reimport': {
        zh: '重新导入资源'
    },

    'Sure to delete this file?': {
        zh: '确认删除选择文件？'
    },

    '{0} cannot be removed(builtin files).': {
        zh: '{0}为内置文件，无法删除。'
    },

    '{0} cannot be modified(builtin files).': {
        zh: '{0}为内置文件，无法编辑。'
    },

    'JavaScript File' : {
        en: 'JavaScript',
        zh: 'JavaScript文件'
    },

    'Enter a new JavaScript file name': {
        zh: '输入JavaScript文件名'
    },

    'Expand': {
        zh: '展开'
    },

    'Collapse': {
        zh: '合并'
    },

    'Enter a new folder name': {
        zh: '请输入目录名'
    },

    'Downscaling is done.': {
        zh: '缩放成功'
    },

    'Please select an animation asset': {
        zh: '请选中一个动画资源'
    },

    'Folder created': {
        zh: '创建目录成功'
    },

    'Failed to create folder': {
        zh: '创建目录失败'
    },

    'Stop running game?': {
        zh: '是否停止当前运行中的游戏？'
    },

    'Stop': {
        zh: '停止'
    },

    'Publish failed:': {
        zh: '发布失败：'
    },

    'Publish succeeded': {
        zh: '发布成功'
    },

    'Remove completed': {
        zh: '删除成功'
    },

    'Remove failed:': {
        zh: '删除失败'
    },

    'Rename succeeded': {
        zh: '重命名完成'
    },

    'Scene saved': {
        zh: '场景保存完成'
    },

    'Prefab saved': {
        zh: '预制保存完成'
    },

    'Built-in files cannot be modified': {
        zh: '内置文件不能被编辑'
    },

    'Reimport completed': {
        zh: '资源重导入完成'
    },

    'Operation completed': {
        zh: '操作成功'
    },

    'Connect failed': {
        zh: '连接失败'
    },

    'Sure to remove this component?': {
        zh: '确定删除此组件？'
    },

    'Remove': {
        zh: '删除'
    },

    'OK': {
        zh: '确定'
    },
    'BitmapFont': {
        zh: 'BitmapFont'
    },

    'Cut': {
        zh: '剪切'
    },

    'Copy': {
        zh: '拷贝'
    },

    'Paste': {
        zh: '粘贴'
    },

    'Create': {
        zh: '创建'
    },

    'Duplicate': {
        zh: '复制'
    },

    'Sure to remove this node?': {
        zh: '确定删除选择节点吗？'
    },

    'Failed to fetch recent projects list': {
        zh: '获取最近打开的工程列表失败。'
    },

    'Open': {
        zh: '打开'
    },

    'Open Project': {
        zh: '打开工程'
    },

    'Failed to open project': {
        zh: '打开工程失败。'
    },

    'Failed to create project': {
        zh: '创建工程失败。'
    },

    'Close Tip': {
        en: 'Make sure the changes you made in the scene are saved.\nYour changes will be lost if you do not save them.\nDo you really want to exit?',
        zh: '请确定所有数据已保存，确定要退出编辑吗？'
    },
    'Folder': {
        zh: '文件夹'
    },

    'Choose Folder': {
        zh: '选择文件夹'
    },

    'Double click to choose the folder': {
        zh: '双击选择文件夹'
    },

    'Please choose a folder to create the project': {
        zh: '请选择创建工程路径'
    },

    'Create a new project': {
        zh: '创建新工程'
    },

    'Project Folder': {
        zh: '工程路径'
    },

    'Recent Opened Projects': {
        en: 'Recent Projects',
        zh: '最近打开的工程'
    },

    'Recent Projects': {
        zh: '最近工程'
    },

    'New Project': {
        zh: '新建工程'
    },

    'Code Editor': {
        zh: '代码编辑器'
    },

    'Code Preview': {
        zh: '代码预览'
    },

    'Code Saved': {
        zh: '代码已保存'
    },

    'Select Object': {
        zh: '选择对象'
    },

    'You are using the latest version.': {
        zh: '当前使用的已经是最新版本。'
    },

    'Local Editor Version: ': {
        zh: '本地编辑器版本：'
    },

    'Latest Editor Version: ': {
        zh: '最新编辑器版本：'
    },

    'Local Core Version: ': {
        zh: '本地核心库版本：'
    },

    'Latest Core Version: ': {
        zh: '最新核心库版本：'
    },

    'Begin to update...' : {
        zh: '开始更新版本...'
    },

    'Update failed, please try again later.': {
        zh: '更新失败，请稍后重试。'
    },

    'Updated successfully, restart the node.js server and refresh this page': {
        zh: '更新成功，请重启后台Node.js服务，并刷新本页面。'
    },

    'Update Info': {
        zh: '更新信息'
    },

    'A new version of QICI Engine is available!': {
        zh: '青瓷引擎有新的版本发布了！'
    },

    'Pan Mode': {
        en: 'Pan',
        zh: '移动场景'
    },

    'Move Mode': {
        en: 'Move',
        zh: '移动元素'
    },

    'Scale Mode': {
        en: 'Scale',
        zh: '缩放'
    },

    'Transform Mode': {
        en: 'Transform',
        zh: '变换'
    },

    'Fit Content': {
        zh: '重置场景大小'
    },

    'Edit in Run': {
        zh: '运行模式下编辑'
    },

    'Show/Hide Grid': {
        zh: '显示/隐藏标尺'
    },

    'Show/Hide Debug': {
        zh: '显示/隐藏调试信息'
    },

    'Checking...': {
        zh: '检查中...'
    },

    'Install': {
        zh: '安装'
    },

    'Installing...': {
        zh: '安装中...'
    },

    'Installed': {
        zh: '已安装'
    },

    '{0} has been successfully installed.': {
        zh: '{0}安装成功'
    },

    '{0} failed to install.': {
        zh: '{0}安装失败'
    },

    'Operate Failed': {
        zh: '操作失败。'
    },

    'Revert to Dragonbones successfully.': {
        zh: '成功还原动作为骨骼动画。'
    },

    'Revert': {
        zh: '还原为骨骼动画。'
    },

    'Loading Prefab': {
        zh: '加载预制'
    },

    'Project has been removed successfully.': {
        zh: '工程已删除'
    },

    'Warning': {
        zh: '警告'
    },

    'Confirm': {
        zh: '确认'
    },

    'Prompt': {
        zh: '提示'
    },

    'Search:': {
        zh: '搜索：'
    },

    'Downloading...': {
        zh: '下载中...'
    },

    'Backup current version...': {
        zh: '备份现有版本中...'
    },

    'Completing update...': {
        zh: '正在完成更新，请稍候...'
    },

    'Update version' : {
        zh : '版本更新'
    },

    'The update is completed, and refresh to load the new version' :  {
        zh : '更新完成，刷新页面载入新版本?'
    },

    'Refresh' : {
        zh : '更新'
    },

    'Failed to update, please make sure no files are occupied by other process.' : {
        zh : '更新失败。请确认文件未被其他进程使用。'
    },

    'Download failed, please try again.' : {
        zh : '下载更新失败，请重试。'
    },

    'Script added.' : {
        zh: '脚本成功挂载在节点上。'
    },

    'Start to download images, count: ' : {
        zh: '开始下载图元，数量'
    },

    'Images downloaded, Start to pack atlas.' : {
        zh: '所有图元已成功下载，开始打包'
    },

    'All atlases has been packed.' : {
        zh: '全部图集打包完毕！！！'
    },

    'Show Retainers' : {
        zh: '查看引用者'
    },

    'Retainers': {
        zh: '引用者'
    },

    'No retainer': {
        zh: '没有其它节点引用此节点'
    },

    'Run in Background': {
        zh: '后台运行'
    },

    'Antialias': {
        zh: '抗锯齿'
    },

    'Transparent': {
        zh: '背景透明'
    },

    'Renderer': {
        zh: '渲染器'
    },

    'Can not move file into raw floder' : {
        zh: '无法将文件移动到raw目录下'
    },

    'Prefab cannot be removed': {
        zh: 'Prefab不能删除'
    },

    'Failed to add component': {
        en: "The component isn't supported by this node.",
        zh: '此节点不支持挂载该组件。'
    },

    "TweenFunction func error": {
        en: 'More than one function with the same name: ',
        zh: '存在多个相同函数名的函数：'
    },

    'Edit': {
        zh: '编辑'
    },

    'Edit Text': {
        zh: '编辑文本'
    },

    'Please input an integer between 1 - 60': {
        zh: '请输入一个 1 - 60 的整数'
    },

    'Sample Frame Rate(1-60, default 15)': {
        zh: '每秒采样帧率（1-60，默认15帧）'
    },

    'Current scripts rely on other, it can not be used as the entrance.' : {
        zh: '当前脚本依赖其他文件，无法作为入口。'
    },

    'Curve Editor': {
        zh: '曲线编辑器'
    },

    'Add Key': {
        zh: '添加关键帧'
    },

    'Delete Key': {
        zh: '删除关键帧'
    },

    'Reset View': {
        zh: '重置显示范围'
    },

    '√ Auto': {
        zh: '√ 自动'
    },

    'Auto': {
        zh: '自动'
    },

    '√ Free Smooth': {
        zh: '√ 平滑'
    },

    'Free Smooth': {
        zh: '平滑'
    },

    '√ Flat': {
        zh: '√ 水平'
    },

    'Flat': {
        zh: '水平'
    },

    '√ Broken': {
        zh: '√ 打断'
    },

    'Broken': {
        zh: '打断'
    },

    '√ Ping Pong': {
        zh: '√ 反复'
    },

    'Ping Pong': {
        zh: '反复'
    },

    '√ Loop': {
        zh: '√ 循环'
    },

    '√ Clamp': {
        zh: '√ 固定'
    },

    'Clamp': {
        zh: '固定'
    },

    'Save as New Curve': {
        zh: '保存为新曲线'
    },

    'Delete Curve': {
        zh: '删除曲线'
    },

    'Add Default Curves': {
        zh: '添加默认曲线'
    },

    'Developer Mode': {
        zh: '开发者模式'
    },

    'Restore': {
        zh: '恢复'
    },

	'Reload': {
        zh: '重新加载'
    },

    'Scene file changed': {
        zh: '</br></br>该文件已变更。</br>是否需要重新加载？</br></br>如果重新加载，该场景未保存的改动将会丢失。',
        en: '</br></br>This file has been modified outside.</br>Do you want to reload it?</br></br>Your unsaved changes in the scene will be lost if you reload it.'
    },

    'State History Size' : {
        en: 'Scene History Count',
        zh: '场景历史记录保存数量'
    },

    'Save Scene Interval': {
        zh: '自动保存临时场景的间隔时间'
    },

    'Use System Editor for JavaScript': {
        zh: '使用系统编辑器打开JavaScript文件'
    },

    'Double Click': {
        zh: '双击'
    },

    'Shift + Double Click': {
        zh: 'Shift + 双击'
    },

    'Current Scene is not {0}, can not revert.' : {
        zh : '当前编辑中的场景并非{0}，不能执行还原操作'
    },

    'Revert Failed.' : {
        zh : '还原失败'
    },
    'Calculate': {
        zh: '计算'
    },
    'Asset is not loaded, please try later.': {
        zh: '资源尚未加载完毕，请稍后再尝试。'
    },
    'Current node is not allowed to add this component.': {
        zh: '当前节点无法添加此组件。'
    },
    'Please first stop to edit prafab.': {
        zh: '请先退出编辑预制状态。'
    },
    'It is not allowed to edit prafab in running mode.': {
        zh: '运行模式下无法编辑预制'
    },
    'Exception notification': {
        en: 'Error: {0}</br></br>Please open \'Developer Tools\'->\'Console\' to see detail.',
        zh: '发生报错：{0}</br></br>打开开发者工具的 Console 面板查看详细信息。'
    },
    'Load Order' : {
        zh: '加载顺序'
    },
    'Script Order Panel' : {
    },
    'My Computer': {
        zh: '我的电脑'
    },
    'Home': {
        zh: '用户目录'
    },
    'Favorites': {
        zh: '收藏夹'
    },
    'Add to Favorites': {
        zh: '添加到收藏夹'
    },
    'Remove from Favorites': {
        zh: '从收藏夹删除'
    },
    'Add, remove and switch order for files or folders': {
        zh: '对脚本文件或目录进行增加、删除和顺序切换'
    },
    'Type': {
        zh: '类型'
    },
    'Save And Reload' : {
        zh: '保存并刷新页面'
    },
    'Repack Texture Atlases': {
        zh: '重新打包图集'
    },
    'Resource not found': {
        zh: '资源已丢失'
    },
    'Dirty Rectangles': {
        zh: '脏矩形'
    },
    'Show Dirty Rectangles': {
        zh: '显示脏矩形区域'
    },
    'Publish failed: Invalid project.': {
        zh: '发布失败：无效工程。'
    },
    'Publish failed: Scene list is empty, please edit setting by menu Project/Settings.': {
        zh: '发布失败：场景列表为空，无法发布游戏，请通过菜单工程-设置进行编辑。'
    },
    'Publish failed: Invalid version, please edit setting by menu Project/Settings.': {
        zh: '发布失败：版本号信息有误，期望[0-9]跟.组成，请在菜单设置中设置版本号。'
    },
    'Mobile': {
        zh: '移动设备'
    },
    'Desktop': {
        zh: '电脑'
    },
    'New Atlas Folder': {
        zh: "创建图集目录"
    },
    'Enter a new atlas folder name:' : {
        en: "Enter a new atlas folder name:<br/><font color='#ff0000'>(The name will be suffixed with '@atlas')</font>",
        zh: "请输入一个新的图集目录名:<br/><font color='#ff0000'>(图集目录名将被自动添加'@atlas'后缀)</font>"
    },
    
    'Server error: invalid directory. The target directory might has been removed.': {
        zh: '服务器错误：invalid directory。目标文件夹可能不存在。'
    }
};
