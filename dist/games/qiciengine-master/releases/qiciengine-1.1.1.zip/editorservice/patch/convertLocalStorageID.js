/**
 * Created by lijh on 03/11/2016
 * 将project.setting中的bundleIdentifier转换为localStorageID
 */

var MY_FLAG = 7;

var path = require('path');
var fs = require('fs-extra');
var convert = function(dir, createFlag) {
    var settingPath = path.join(dir, 'ProjectSetting/project.setting');
    if (!fs.existsSync(settingPath))
        return;

    var projectConf = null;
    try {
        projectConf = fs.readJsonSync(settingPath, { throws : false });
    }
    catch(e) {
    }
    if (!projectConf) return;

    var toolFlag = projectConf.toolFlag || 0;
    if (toolFlag & (1 << MY_FLAG)) {
        // 处理过了
        return;
    }

    // 设置回写
    projectConf.toolFlag = (toolFlag | (1 << MY_FLAG));

    if (createFlag) {
        G.load('filesystem/FsExpand').writeJsonSync(settingPath, projectConf);
        return;
    }

    // 转换 bundleIdentifier 为 localStorageID
    projectConf.localStorageID = projectConf.bundleIdentifier;
    delete projectConf.bundleIdentifier;
    G.load('filesystem/FsExpand').writeJsonSync(settingPath, projectConf);
};

// 打开工程、切换工程的时候尝试 convert
G.emitter.on('switchProject', function(createFlag) {
    convert(G.gameRoot, createFlag);
});

