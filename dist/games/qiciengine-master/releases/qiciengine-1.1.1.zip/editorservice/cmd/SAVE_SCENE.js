/**
 * @author weism
 * copyright 2015 Qcplay All Rights Reserved.
 *
 * 保存场景
 */

M.COMMAND.registerCmd({
    name : 'SAVE_SCENE',
    main : function(socket, cookie, data) {
        var path = data.path;
        var json = data.data;

        var ret = M.SCENE_MANAGER.saveScene(path, json);
        if (ret) {
            // 重新生成游戏启动文件
            G.log.debug('update scene settings.');
            M.PROJECT.genGameHTML();
        }
        return ret;
    }
});
