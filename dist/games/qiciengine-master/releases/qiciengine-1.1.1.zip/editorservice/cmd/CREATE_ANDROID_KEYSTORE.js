/**
 * @author chenqx
 * copyright 2015 Qcplay All Rights Reserved.
 */

/*
 * 生成安卓Keystore文件
 */

M.COMMAND.registerCmd({
    name : 'CREATE_ANDROID_KEYSTORE',
    main : function(socket, cookie, data) {
        return M.PROJECT.createAndroidKeystore(data);
    }
});

