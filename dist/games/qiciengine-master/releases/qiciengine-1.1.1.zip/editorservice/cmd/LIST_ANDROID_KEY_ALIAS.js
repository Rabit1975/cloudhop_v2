/**
 * @author chenqx
 * copyright 2015 Qcplay All Rights Reserved.
 */

/*
 * 获取安卓Keystore文件的alias列表
 */

M.COMMAND.registerCmd({
    name : 'LIST_ANDROID_KEY_ALIAS',
    main : function(socket, cookie, data) {
        return M.PROJECT.listAndroidKeystore(data);
    }
});


