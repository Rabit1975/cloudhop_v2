# 拓展UI插件
在游戏开发中，为了性能等因素，需要一些特殊的UI处理方式。本插件整合一些常用的功能，对引擎的UI系统进行拓展。

# 组件说明
* [滚动支持(ScrollSupport)](components/ScrollSupport.md)
* [表格数据适配器(TableViewAdapter)](components/TableViewAdapter.md)
* [表格视图(TableView)](components/TableView.md)
