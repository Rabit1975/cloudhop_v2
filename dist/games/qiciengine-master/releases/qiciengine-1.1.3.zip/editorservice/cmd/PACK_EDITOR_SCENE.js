/**
 * @author weism
 * copyright 2015 Qcplay All Rights Reserved.
 *
 * 请求打包编辑器中编辑的场景
 */
COMMAND_D.registerCmd({
    name : 'PACK_EDITOR_SCENE',
    main : function(socket, cookie, paras) {
    }
});
