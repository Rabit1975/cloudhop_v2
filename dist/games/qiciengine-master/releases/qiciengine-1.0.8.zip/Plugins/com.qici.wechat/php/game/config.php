<?php
// 微信内登录
// 平台的APPID
define('APPID', 'wxf9d939798xxxxxxx');

// 平台的秘钥
define('APP_SECRET', '26147c2a936fexxxxxx');

// 微信外登录
// 平台的APPID
define('APPID_PC', 'wxd464047dxxxxx');

// 平台的秘钥
define('APP_SECRET_PC', 'd4624c36b6795dxxxxxxx');
?>