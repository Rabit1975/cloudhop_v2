/**
 * @author wudm
 * @copyright 2016 Qcplay All Rights Reserved.
 */

/**
 * Box2D body 对象
 */
var Body = qc.defineBehaviour('qc.Box2D.Body', qc.Behaviour, function() {
    // 记录自身对象
    this.gameObject.body = this;

    // 记录世界对象
    this.gameObject.world = this.game.phaser.physics.box2d;

    var body = this.gameObject._body;
    if (!body) body = this.gameObject._body = {};

    // 初始化 fixture 列表为默认
    body.fixture = [ {
        type : Body.FIXTURE_TYPE.POLYGON,
        density : 1.0,
        friction : 0.1,
        restitution : 0.2,
        sensor : false,
    } ];

    // 初始化必要的属性
    body.type = Body.TYPE.STATIC;

    // 是否进入 awake 状态
    body.isAwake = true;

    // 子弹模式（避免 tunneling）
    body.bullet = false;

    // 转向固定
    body.fixedRotation = false;

    // 角速度
    body.angularVelocity = 0;

    // 角阻抗
    body.angularDamping = 0;

    // 速度
    body.linearVelocity = new qc.Point(0, 0);

    // 线性阻抗
    body.linearDamping = 0;

    // 重力倍数
    body.gravityScale = 1;

    // 碰撞事件
    this.onContact = new qc.Signal();

    // Presolve 事件
    this.onPreSolve = new qc.Signal();

    // Postsolve 事件
    this.onPostSolve = new qc.Signal();

    // 初始化事件
    this.onBodyCreated = new qc.Signal();

    // 形状变化事件
    this.onFixtureChanged = new qc.Signal();
}, {
    // 需要序列化的属性情况
    type : qc.Serializer.INT,
    isAwake : qc.Serializer.BOOLEAN,
    bullet : qc.Serializer.BOOLEAN,
    angularVelocity : qc.Serializer.NUMBER,
    angularDamping : qc.Serializer.NUMBER,
    fixedRotation : qc.Serializer.BOOLEAN,
    linearDamping : qc.Serializer.BOOLEAN,
    linearVelocity : qc.Serializer.POINT,
    gravityScale : qc.Serializer.NUMBER,
    fixture : {
        get : function(ob, context) {
            // 将 fixture 信息序列化下来成数组
            var body = ob.gameObject._body;
            var len = body.fixture.length;
            var v = new Array(len);
            for (var i = 0; i < len; i++) {
                var fixture = body.fixture[i];
                v[i] = {
                    type : fixture.type,
                    density : fixture.density,
                    friction : fixture.friction,
                    restitution : fixture.restitution,
                    sensor : fixture.sensor,
                    // shape : ob.body._serializeFixtureShape(fixture)
                };
            }
            return v;
        },
        set : function(context, v) {
            // 将反序列化出来的数组，在内存中还原出 fixtures
            var body = context.gameObject._body;
            var len = v.length;
            var fixtures = body.fixture = new Array(len);
            for (var i = 0; i < len; i++) {
                var fixture = v[i];
                fixtures[i] = {
                    type : fixture.type,
                    density : fixture.density,
                    friction : fixture.friction,
                    restitution : fixture.restitution,
                    sensor : fixture.sensor,
                };
                // ob.body._restoreFixtureShape(fixtures[i], fixture);
            }
        }
    }
});

// Body 类型定义，分别为静止、运动学物体、动态物体
Body.TYPE = {};
Body.TYPE.STATIC = 0;
Body.TYPE.KINEMATIC = 1;
Body.TYPE.DYNAMIC = 2;

// 形状定义：多边形、圆、链条
Body.FIXTURE_TYPE = {};
Body.FIXTURE_TYPE.POLYGON = 0;
Body.FIXTURE_TYPE.CIRCLE = 1;
Body.FIXTURE_TYPE.CHAIN = 2;

// Called when the script instance is being loaded.
Body.prototype.awake = function() {

};

// Called every frame, if the behaviour is enabled.
Body.prototype.update = function() {
    if (!this.enable) return;

    // 只有可见物体才有 update 方法，确保可见物体存在 body
    if (!this.gameObject.b2Body)
        this.createBody();
};

/**
 * 序列化 fixture 的形状
 */
Body.prototype._serializeFixtureShape = function(fixture) {
    var i, len;
    switch (fixture.type) {
    case Body.FIXTURE_TYPE.CIRCLE :
        return [ fixture.radius, fixture.center.x, fixture.center.y ];
    case Body.FIXTURE_TYPE.POLYGON :
    case Body.FIXTURE_TYPE.CHAIN :
        len = fixture.vertices.length;
        var verts = new Array(len * 2);
        for (i = 0; i < len; i++) {
            verts[i * 2] = fixture.vertices[i].x;
            verts[i * 2 + 1] = fixture.vertices[i].y;
        }
        return verts;
    }
    return [];
};

/**
 * 将 fixture 的形状反序列化出来
 */
Body.prototype._restoreFixtureShape = function(fixture, v) {
    var i, len;
    switch (fixture.type) {
    case Body.FIXTURE_TYPE.CIRCLE :
        fixture.radius = v[0];
        fixture.center = new qc.Point(v[1], v[2]);
        break;
    case Body.FIXTURE_TYPE.POLYGON :
    case Body.FIXTURE_TYPE.CHAIN :
        len = v.length / 2;
        fixture.vertices = new Array(len);
        for (i = 0; i < len; i++) {
            fixture.vertices[i] = new qc.Point(verts[i * 2], verts[i * 2 + 1]);
        }
        break;
    }
};

/**
 * 对象激活的时候处理设置 box2d 世界 body
 */
Body.prototype.onEnable = function() {
    // 延迟到 update 中处理，enable 中经常没有挂好 parent，后续 scale 等
    // 信息会变化，会触发 reset fixture，所以新创建的目标会二次 create fixture
    // this.createBody();
};

/**
 * 对象取消激活的处理
 */
Body.prototype.onDisable = function() {
    this.removeBody();
};

/**
 * 添加自己到物理世界中
 */
Body.prototype.createBody = function() {
    var b2BodyDef = new Box2D.b2BodyDef();

    // 属性逐一设置
    var self = this;
    var gameObject = self.gameObject;
    var body = gameObject._body;
    switch (body.type) {
    case Body.TYPE.DYNAMIC : b2BodyDef.set_type(Box2D.b2_dynamicBody); break;
    case Body.TYPE.KINEMATIC : b2BodyDef.set_type(Box2D.b2_kinematicBody); break;
    default : b2BodyDef.set_type(Box2D.b2_staticBody); break;
    }
    b2BodyDef.set_awake(body.isAwake);
    b2BodyDef.set_bullet(body.bullet);
    b2BodyDef.set_angularVelocity(body.angularVelocity);
    b2BodyDef.set_angularDamping(body.angularDamping);
    b2BodyDef.set_fixedRotation(body.fixedRotation);
    b2BodyDef.set_linearDamping(body.linearDamping);

    b2BodyDef.set_linearVelocity(Box2D.Vec2Proxy(body.linearVelocity.x, body.linearVelocity.y));
    b2BodyDef.set_gravityScale(body.gravityScale);

    // 设置世界物体的属性给目标对象
    var x, y, rotation;
    if (self.game.box2d.flatten) {
        x = gameObject.x;
        y = gameObject.y;
        rotation = gameObject.rotation;
    }
    else {
        var pos = gameObject.getWorldPosition();
        x = pos.x;
        y = pos.y;
        rotation = gameObject.getWorldRotation();
    }

    // 设置初始位置
    b2BodyDef.set_position(Box2D.Vec2Proxy(
        self.game.box2d.pixelToMeter(pos.x),
        self.game.box2d.pixelToMeter(pos.y)
    ));

    // 设置初始角度
    b2BodyDef.set_angle(rotation);

    // 记录缓存
    body.lastTransform = {
        rotation : rotation,
        x : x,
        y : y
    };

    // 创建出来并记录
    var b2Body = self.game.box2d.createBody(b2BodyDef);
    gameObject.b2Body = b2Body;
    b2Body.behaviour = self;
    b2Body.gameObject = gameObject;

    // 设置默认的 fixture
    self.resetFixtureShape();

    // 给出创建完毕 Body 的事件
    self.onBodyCreated.dispatch(gameObject);
};

/**
 * 删除自己
 */
Body.prototype.removeBody = function() {
    // 取消物理世界中的 body 对象
    this.gameObject.world.destroyBody(this.gameObject);
    this.gameObject.b2Body = null;
};

/**
 * 根据 body.fixture 数据，加载到 box2d 中
 */
Body.prototype.loadFixtures = function() {
    var ob = this.gameObject;
    var b2Body = ob.b2Body;
    if (!b2Body) return;

    var fixtures = ob._body.fixture;
    if (!fixtures || !fixtures.length) return;

    var len = fixtures.length;
    for (var i = 0; i < len; i++) {
        this._loadFixture(ob.world, b2Body, fixtures[i]);
    }

    this.onFixtureChanged.dispatch(ob);
};

/**
 * 人为设置各个点，后续通过工具生成
 */
Body.prototype.setPolygonVertices = function(vertices, isNormalize) {
    var len = vertices.length;
    if (!len) return;

    var customPolygon;
    var i;
    var p = vertices[0];
    if (typeof p.x === 'number' && typeof p.y === 'number') {
        customPolygon = vertices;
    }
    else {
        customPolygon = new Array(len / 2);
        for (i = 0; i < len / 2; i++) {
            customPolygon[i] = {
                x : vertices[i * 2],
                y : vertices[i * 2 + 1]
            };
        }
    }

    // 非归一化后的坐标，传入的是世界的坐标，转换之
    if (!isNormalize) {
        var worldScale = this.gameObject.getWorldScale();
        for (i = 0, len = customPolygon.length; i < len; i++) {
            customPolygon[i].x /= worldScale.x;
            customPolygon[i].y /= worldScale.y;
        }
    }

    this.gameObject.body.customPolygon = customPolygon;
    this.resetFixtureShape();
};

/**
 * 初始化默认的 Fixture Shape
 */
Body.prototype.resetFixtureShape = function() {
    // 先清空之前所有的 fixture
    this.clearFixtures();

    var node = this.gameObject;
    var b2Body = node.b2Body;

    var worldScale = node.getWorldScale();
    var fixture = node._body.fixture[0];

    var customPolygon = node.body.customPolygon;
    var corners, i, len;

    if (customPolygon) {
        len = customPolygon.length;
        corners = new Array(customPolygon.length);
        for (i = 0; i < len; i++) {
            corners[i] = new qc.Point(
                customPolygon[i].x * worldScale.x,
                customPolygon[i].y * worldScale.y);
        }
    }
    else {
        corners = qc.Bounds.getCorners(node, 0, false, 0, node);

        for (i = 0, len = corners.length; i < len; i++) {
            corners[i].x *= worldScale.x;
            corners[i].y *= worldScale.y;
        }
    }

    if (fixture.type === Body.FIXTURE_TYPE.POLYGON) {
        fixture.vertices = corners;
    }
    else if (fixture.type === Body.FIXTURE_TYPE.CIRCLE) {
        var p1 = corners[0];
        var p2 = corners[2];

        fixture.center = new qc.Point((p1.x + p2.x) / 2, (p1.y + p2.y) / 2);
        fixture.radius = Math.max(Math.abs(p1.x - p2.x) / 2, Math.abs(p1.y - p2.y) / 2);
    }

    // 加载新的 fixture 进来
    this.loadFixtures();

    // 记录系数
    node._body.pivotX = node.pivotX;
    node._body.pivotY = node.pivotY;
    node._body.width = node.width;
    node._body.height = node.height;

    if (!node.parent ||
        node.parent === node.game.world ||
        node.game.box2d.flatten) {
        node._body.scaleSqrX = node.scaleX * node.scaleX;
        node._body.scaleSqrY = node.scaleY * node.scaleY;
    }
    else {
        var wt = node.worldTransform;
        node._body.scaleSqrX = (wt.a * wt.a + wt.b * wt.b);
        node._body.scaleSqrY = (wt.c * wt.c + wt.d * wt.d);
    }
};

/**
 * pre update 阶段尝试更新
 */
Body.prototype.bodyPreUpdate = function() {
    var ob = this.gameObject;
    if (!ob.worldVisible) {
        if (this.gameObject.b2Body) {
            this.removeBody();
            return;
        }
    }

    var body = ob._body;
    var bwt = body.lastTransform;
    var x, y, rotation;
    var scaleSqrX, scaleSqrY;

    if (!ob.parent ||
        ob.parent === ob.game.world ||
        ob.game.box2d.flatten) {
        rotation = ob.rotation;
        x = ob.x;
        y = ob.y;
        scaleSqrX = ob.scaleX * ob.scaleX;
        scaleSqrY = ob.scaleY * ob.scaleY;
    }
    else {
        var wt = ob.worldTransform;
        rotation = Math.atan2(wt.b, wt.a);
        x = wt.tx;
        y = wt.ty;
        scaleSqrX = wt.a * wt.a + wt.b * wt.b;
        scaleSqrY = wt.c * wt.c + wt.d * wt.d;
    }

    // 位移是否发生变化
    var offsetChanged = (Math.abs(x - bwt.x) > 0.01 ||
                         Math.abs(y - bwt.y) > 0.01);

    // 旋转是否发生变化
    var rotationChanged = Math.abs(rotation - bwt.rotation) > 0.0001;

    // 缩放是否发生变化
    var scaleChanged = Math.abs(scaleSqrX - body.scaleSqrX) > 0.001 ||
                       Math.abs(scaleSqrY - body.scaleSqrY) > 0.001;

    // pivot/width/height是否发生变化
    var anchor = ob.phaser.anchor || {};
    var pivotChanged = (anchor.x !== body.pivotX || anchor.y !== body.pivotY);
    var sizeChanged = (ob._width !== body.width || ob._height !== body.height);

    if (scaleChanged || pivotChanged || sizeChanged) {
        this.resetFixtureShape();
    }

    if (offsetChanged || rotationChanged) {
        // 设置世界物体的属性给目标对象

        // 设置初始位置
        ob._body.lastTransform = {
            rotation : rotation,
            x : x,
            y : y
        };
        ob.b2Body.SetTransform(Box2D.Vec2Proxy(
            ob.game.box2d.pixelToMeter(x),
            ob.game.box2d.pixelToMeter(y)
        ), rotation);
    }
};

/**
 * post update 阶段同步 box2d 世界的信息到普通世界
 */
Body.prototype.bodyPostUpdate = function() {
    // 同步角度，位置
    var b2Body = this.gameObject.b2Body;
    if (!b2Body) return;

    // static 物体不同步给世界
    if (this.gameObject._body.type === Body.TYPE.STATIC)
        return;

    var b2Pos = b2Body.GetPosition();

    var b2x = b2Pos.get_x();
    var b2y = b2Pos.get_y();
    if (isNaN(b2x) || isNaN(b2y))
        return;

    // 设置属性到对象身上
    var ob = this.gameObject;
    var world = ob.world;

    var tx = world.meterToPixel(b2x);
    var ty = world.meterToPixel(b2y);
    var rotation = b2Body.GetAngle();

    ob._body.lastTransform = {
        rotation : rotation,
        x : tx,
        y : ty
    };

    // 如果没有父亲，或者是 flatten 世界，rotation/tx/ty 就是最终信息，直接设置
    var parent = ob.parent;
    if (!parent ||
        parent === ob.game.world ||
        world.flatten) {
        ob.x = tx;
        ob.y = ty;
        ob.rotation = rotation;
        return;
    }

    var wt = ob.phaser.worldTransform;
    var cosRot = Math.cos(rotation);
    var sinRot = Math.sin(rotation);
    var parentTrans = ob.parent.worldTransform;
    var parentMatrix, out;

    if (Math.abs(wt.b / wt.a - sinRot / cosRot) < 0.0001) {
        // 旋转没有发生变化
        parentMatrix = parentTrans.toArray(true);
        out = [];

        // 计算出相对父节点的偏移
        this.game.math.invert(out, parentMatrix);
        this.game.math.multiply(out, out,
            [wt.a, wt.b, 0, wt.c, wt.d, 0, tx, ty, 1]);

        // 设置给物体
        ob.x = out[6];
        ob.y = out[7];
    }
    else {
        // 旋转发生变化了
        var worldScale = ob.getWorldScale();
        var scaleX = worldScale.x;
        var scaleY = worldScale.y;

        parentMatrix = parentTrans.toArray(true);
        out = [];

        // 计算出相对父节点的偏移
        this.game.math.invert(out, parentMatrix);
        this.game.math.multiply(out, out,
            [ cosRot * scaleX,
              sinRot * scaleX,
              0,
              -sinRot * scaleY,
              cosRot * scaleY,
              0,
              tx,
              ty,
              1 ]);

        ob.rotation = Math.atan2(out[1], out[0]);
        ob.x = out[6];
        ob.y = out[7];
    }
};

/**
 * 加上一道外力作用在 body 上
 */
Body.prototype.applyForce = function(x, y) {
    var b2Body = this.gameObject.b2Body;
    b2Body.ApplyForce(Box2D.Vec2Proxy(-x, -y),
        b2Body.GetWorldCenter(), true);
};

/**
 * 是否包含一个点
 */
Body.prototype.contains = function(x, y) {
    var point = Box2D.Vec2Proxy(this.gameObject.world.pixelToMeter(x),
                                 this.gameObject.world.pixelToMeter(y));

    // 先收集所有的 Fixtures
    var b2Body = this.gameObject.b2Body;
    for (var fixture = b2Body.GetFixtureList(); fixture.e; fixture = fixture.GetNext()) {
        if (fixture.TestPoint(point))
            return true;
    }

    // 没有找到任何 Fixtuer 包含之
    return false;
};

/**
 * 加载单个 fixture 对象
 */
Body.prototype._loadFixture = function(world, body, fixtureDef) {
    var fixture = Box2D.b2FixtureDefProxy();

    fixture.set_density(1.0 * fixtureDef.density || 0);
    fixture.set_friction(fixtureDef.friction || 0);
    fixture.set_restitution(fixtureDef.restitution || 0);
    fixture.set_isSensor(fixtureDef.sensor || false);

    var shape;
    switch (fixtureDef.type) {
    case Body.FIXTURE_TYPE.CIRCLE :
        shape = Box2D.b2CircleShapeProxy();
        shape.set_m_radius(world.pixelToMeter(fixtureDef.radius || 0));
        if (fixtureDef.center)
            shape.set_m_p(Box2D.Vec2Proxy(
                world.pixelToMeter(fixtureDef.center.x),
                world.pixelToMeter(fixtureDef.center.y)));
        else
            shape.set_m_p(Box2D.Vec2Proxy(0, 0));
        break;

    case Body.FIXTURE_TYPE.POLYGON :
    case Body.FIXTURE_TYPE.CHAIN :
        // 生成形状
        if (fixtureDef.type === Body.FIXTURE_TYPE.POLYGON)
            shape = Box2D.b2PolygonShapeProxy();
        else
            shape = Box2D.b2ChainShapeProxy();

        var vertices = fixtureDef.vertices;
        var buffer = Box2D.b2VerticesBufferProxy(vertices.length);
        var offset = 0;

        for (var i = 0, len = vertices.length; i < len; i++) {
            Box2D.setValue(buffer + (offset),
                world.pixelToMeter(vertices[i].x), 'float');
            Box2D.setValue(buffer + (offset + 4),
                world.pixelToMeter(vertices[i].y), 'float');
            offset += 8;
        }

        var ptr_wrapped = Box2D.wrapPointer(buffer, Box2D.b2Vec2);

        if (fixtureDef.type === Body.FIXTURE_TYPE.POLYGON)
            shape.Set(ptr_wrapped, vertices.length);
        else
            shape.CreateChain(ptr_wrapped, vertices.length);
        break;
    }

    fixture.set_shape(shape);
    body.CreateFixture(fixture);
};

/**
 * 清除所有的 Fixture
 */
Body.prototype.clearFixtures = function() {
    var fixtures = [];
    var fixture;
    var b2Body = this.gameObject.b2Body;

    // 先收集所有的 Fixtures
    for (fixture = b2Body.GetFixtureList(); fixture.e; fixture = fixture.GetNext()) {
        fixtures.push(fixture);
    }

    // 逐一析构掉
    var i, len = fixtures.length;
    for (i = 0; i < len; i++) {
        b2Body.DestroyFixture(fixtures[i]);
    }
};

/**
 * 获取一个 filter 对象
 */
Body.prototype._getBox2DFilter = function() {
    var b2Body = this.gameObject.b2Body;
    if (!b2Body) return null;

    var fixture = b2Body.GetFixtureList();
    if (!fixture) return null;

    return fixture.GetFilterData();
};

/**
 * 获取所有的 filter 对象
 */
Body.prototype._getBox2DFilters = function() {
    var b2Body = this.gameObject.b2Body;
    if (!b2Body) return null;

    var filters = [];
    var fixture;

    for (fixture = b2Body.GetFixtureList(); fixture.e; fixture = fixture.GetNext()) {
        filters.push(fixture.GetFilterData());
    }
    return filters;
};

/**
 * 清除具体某个Fixture
 */
Body.prototype.removeFixture = function(fixture) {
    var b2Body = this.gameObject.b2Body;
    if (fixture.GetBody() !== b2Body)
        return false;

    b2Body.DestroyFixture(fixture);
    return true;
};

Object.defineProperties(Body.prototype, {
    /**
     * body的类型，目前包括动态类型、静态类型、运动学物体
     */
    type : {
        get : function() { return this.gameObject._body.type; },
        set : function(v) {
            this.gameObject._body.type = v;
            var b2Body = this.gameObject.b2Body;
            if (!b2Body) return;
            switch (v) {
            case Body.TYPE.DYNAMIC : b2Body.SetType(Box2D.b2_dynamicBody); break;
            case Body.TYPE.KINEMATIC : b2Body.SetType(Box2D.b2_kinematicBody); break;
            default : b2Body.SetType(Box2D.b2_staticBody); break;
            }
        }
    },

    /**
     * 是否激活中（非激活中的物体会以很低的开销存活，直到被碰撞之后重新 awake）
     */
    isAwake : {
        get : function() { return this.gameObject._body.isAwake; },
        set : function(v) {
            this.gameObject._body.isAwake = v;
            var b2Body = this.gameObject.b2Body;
            if (b2Body) b2Body.SetAwake(v);
        }
    },

    /**
     * 是否是子弹类型，子弹类型是用于高速运动的物体，设置该属性可以避免部分穿墙
     */
    bullet : {
        get : function() { return this.gameObject._body.bullet; },
        set : function(v) {
            this.gameObject._body.bullet = v;
            var b2Body = this.gameObject.b2Body;
            if (b2Body) b2Body.SetBullet(v);
        }
    },

    /**
     * 角速度
     */
    angularVelocity : {
        get : function() {
            if (this.gameObject.b2Body)
                return this.gameObject.b2Body.GetAngularVelocity();
            return this.gameObject._body.angularVelocity;
        },
        set : function(v) {
            this.gameObject._body.angularVelocity = v;
            var b2Body = this.gameObject.b2Body;
            if (b2Body) b2Body.SetAngularVelocity(v);
        }
    },

    /**
     * 旋转阻尼
     */
    angularDamping : {
        get : function() { return this.gameObject._body.angularDamping; },
        set : function(v) {
            this.gameObject._body.angularDamping = v;
            var b2Body = this.gameObject.b2Body;
            if (b2Body) b2Body.SetAngularDamping(v);
        }
    },

    /**
     * 是否固定旋转
     */
    fixedRotation : {
        get : function() { return this.gameObject._body.fixedRotation; },
        set : function(v) {
            this.gameObject._body.fixedRotation = v;
            var b2Body = this.gameObject.b2Body;
            if (b2Body) b2Body.SetFixedRotation(v);
        }
    },

    /**
     * 线性阻尼
     */
    linearDamping : {
        get : function() { return this.gameObject._body.linearDamping; },
        set : function(v) {
            this.gameObject._body.linearDamping = v;
            var b2Body = this.gameObject.b2Body;
            if (b2Body) b2Body.SetLinearDamping(v);
        }
    },

    /**
     * 线速度
     */
    linearVelocity : {
        get : function() {
            var b2Body = this.gameObject.b2Body;
            if (b2Body) {
                var b2Pos = b2Body.GetPosition();
                return new qc.Point(b2Pos.get_x(), b2Pos.get_y());
            }
            return this.gameObject._body.linearVelocity;
        },
        set : function(v) {
            this.gameObject._body.linearVelocity = v;
            var b2Body = this.gameObject.b2Body;
            if (b2Body) b2Body.SetLinearVelocity(Box2D.Vec2Proxy(v.x, v.y));
        }
    },

    /**
     * 响应重力的倍率
     */
    gravityScale : {
        get : function() { return this.gameObject._body.gravityScale; },
        set : function(v) {
            this.gameObject._body.gravityScale = v;
            var b2Body = this.gameObject.b2Body;
            if (b2Body) b2Body.SetGravityScale(v);
        }
    },

    /**
     * 质量系数
     */
    density : {
        get : function() {
            var fixtures = this.gameObject._body.fixture;
            if (!fixtures || !fixtures.length) return 0;
            return fixtures[0].density;
        },
        set : function(v) {
            var fixtures = this.gameObject._body.fixture;
            var i, len = fixtures.length;
            for (i = 0; i < len; i++)
                fixtures[i].density = v;

            // 设置到世界中
            var fixture, b2Body = this.gameObject.b2Body;
            for (fixture = b2Body.GetFixtureList(); fixture.e; fixture = fixture.GetNext())
                fixture.SetDensity(v);
            b2Body.ResetMassData();
        }
    },

    /**
     * 摩擦力
     */
    friction : {
        get : function() {
            var fixtures = this.gameObject._body.fixture;
            if (!fixtures || !fixtures.length) return 0;
            return fixtures[0].friction;
        },
        set : function(v) {
            var fixtures = this.gameObject._body.fixture;
            var i, len = fixtures.length;
            for (i = 0; i < len; i++)
                fixtures[i].friction = v;

            // 设置到世界中
            var fixture, b2Body = this.gameObject.b2Body;
            for (fixture = b2Body.GetFixtureList(); fixture.e; fixture = fixture.GetNext()) {
                fixture.SetFriction(v);
                fixture.Refilter();
            }
        }
    },

    /**
     * 恢复系数
     */
    restitution : {
        get : function() {
            var fixtures = this.gameObject._body.fixture;
            if (!fixtures || !fixtures.length) return 0;
            return fixtures[0].restitution;
        },
        set : function(v) {
            var fixtures = this.gameObject._body.fixture;
            var i, len = fixtures.length;
            for (i = 0; i < len; i++)
                fixtures[i].restitution = v;

            // 设置到世界中
            var fixture, b2Body = this.gameObject.b2Body;
            for (fixture = b2Body.GetFixtureList(); fixture.e; fixture = fixture.GetNext()) {
                fixture.SetRestitution(v);
                fixture.Refilter();
            }
        }
    },

    /**
     * 是否传感器
     */
    sensor : {
        get : function() {
            var fixtures = this.gameObject._body.fixture;
            if (!fixtures || !fixtures.length) return 0;
            return fixtures[0].sensor;
        },
        set : function(v) {
            var fixtures = this.gameObject._body.fixture;
            var i, len = fixtures.length;
            for (i = 0; i < len; i++)
                fixtures[i].sensor = v;

            // 设置到世界中
            var fixture, b2Body = this.gameObject.b2Body;
            for (fixture = b2Body.GetFixtureList(); fixture.e; fixture = fixture.GetNext()) {
                fixture.SetSensor(v);
                fixture.Refilter();
            }
        }
    },

    /**
     * fixture类型
     */
    fixtureType : {
        get : function() {
            var fixtures = this.gameObject._body.fixture;
            if (!fixtures || !fixtures.length) return 0;
            return fixtures[0].type;
        },
        set : function(v) {
            var fixtures = this.gameObject._body.fixture;
            var i, len = fixtures.length;
            for (i = 0; i < len; i++)
                fixtures[i].type = v;

            // 重置所有 fixture
            this.resetFixtureShape();
        }
    },

    /**
     *  category bits
     */
    categoryBits : {
        get : function() {
            var filterData = this._getBox2DFilter();
            if (filterData)
                filterData.get_categoryBits();
            else
                return 0x0001;
        },
        set : function(v) {
            var filters = this._getBox2DFilters();
            for (var i = 0, len = filters.length; i < len; i++) {
                var filter = filters[i];
                filter.set_categoryBits(v);
            }
        }
    },

    /**
     * mask bits
     */
    maskBits : {
        get : function() {
            var filterData = this._getBox2DFilter();
            if (filterData)
                filterData.get_maskBits();
            else
                return -1;
        },
        set : function(v) {
            var filters = this._getBox2DFilters();
            for (var i = 0, len = filters.length; i < len; i++) {
                var filter = filters[i];
                filter.set_maskBits(v);
            }
        }
    },

    /**
     * group index
     */
    groupIndex : {
        get : function() {
            var filterData = this._getBox2DFilter();
            if (filterData)
                filterData.get_groupIndex();
            else
                return 0;
        },
        set : function(v) {
            var filters = this._getBox2DFilters();
            for (var i = 0, len = filters.length; i < len; i++) {
                var filter = filters[i];
                filter.set_groupIndex(v);
            }
        }
    }
});
