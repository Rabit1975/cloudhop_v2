/*
* copyright 2015 Qcplay All Rights Reserved.
*
* editorservice 的版本号
*/

G.VERSION = '1.0.8';
