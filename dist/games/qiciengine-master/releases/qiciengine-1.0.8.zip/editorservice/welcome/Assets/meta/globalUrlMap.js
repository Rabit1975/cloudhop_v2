urlMapConfig = {
  "0b19d306-d446-42e1-bdeb-bc73a19ed260": "Assets/atlas/background.bin",
  "b34dfdeb-b442-4aac-9158-382002658857": "Assets/atlas/project.bin",
  "1be6f7db-3474-4d52-8afb-3adc8f9d9d93": "Assets/atlas/project@atlas/browser.bin",
  "f42d0c98-5e02-44c5-a382-0cbcd9f0904b": "Assets/atlas/project@atlas/create_btn.bin",
  "3eb39c0b-b37c-42b9-b0ca-6d473013f5b1": "Assets/atlas/project@atlas/head_line.bin",
  "19cb1022-8852-4014-825c-9f4189ea10b2": "Assets/atlas/project@atlas/path.bin",
  "93e1ec88-86d0-4d8e-9df6-a1bf6e7c5884": "Assets/atlas/project@atlas/path_background.bin",
  "a4048822-defd-492a-9493-bec8d1b26d41": "Assets/atlas/project@atlas/path_select.bin",
  "033a3cc3-4082-4782-a21d-f89e14079342": "Assets/atlas/project@atlas/qici.bin",
  "ec06edf4-82ab-423c-a20c-9ed19a3f9f56": "Assets/atlas/project@atlas/small_logo.bin",
  "e84f4dd5-8b0f-4acd-bf4d-bade44d25dc8": "Assets/atlas/project@atlas/top_bg.bin",
  "cfe6efa1-14b9-4efe-8f3b-d093b7f05fa9": "Assets/prefab/item.bin",
  "9e3081a6-988a-4eee-ad04-92500ce566cc": "Assets/scene/Main.bin",
  "a9ed1c1a-6c92-4f20-85e4-e150ce879a4f": "Temp/scene_editor.bin"
};
