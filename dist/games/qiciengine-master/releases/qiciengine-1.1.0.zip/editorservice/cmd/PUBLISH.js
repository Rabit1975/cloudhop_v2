/**
 * @author wudm
 * copyright 2015 Qcplay All Rights Reserved.
 *
 * 用户发布游戏
 */
var fs = require('fs-extra');
var path = require('path');

var deleteFolderRecursive = function(path) {

    var files = [];

    if( fs.existsSync(path) ) {

        files = fs.readdirSync(path);

        files.forEach(function(file,index){

            var curPath = path + "/" + file;

            if(fs.statSync(curPath).isDirectory()) { // recurse

                deleteFolderRecursive(curPath);

            } else { // delete file

                fs.unlinkSync(curPath);

            }

        });

        fs.rmdirSync(path);

    }

};

M.COMMAND.registerCmd({
    name : 'PUBLISH',
    main : function(socket, cookie, param) {
        var platform = param.platform || 'browsers';
        var publishPath = path.join(G.config.project.publish[platform.toLowerCase()] || 'Build', 'PublishProject');
        if (!path.isAbsolute(publishPath)) {
            publishPath = path.join(G.gameRoot, publishPath);
        }
        if (fs.existsSync(publishPath)) {
            deleteFolderRecursive(publishPath);
        }
        //var tsHms = new Date();
        //var platform = param.platform || 'Browsers';
        //var buildBasePath = path.join(G.config.project.publish[platform.toLowerCase()] || 'Build', 'ver' +
            //tsHms.getFullYear() +
            //("0" + (tsHms.getMonth() + 1)).slice(-2) +
            //("0" + (tsHms.getDate())).slice(-2) +
            //("0" + tsHms.getHours()).slice(-2) +
            //("0" + tsHms.getMinutes()).slice(-2) +
            //("0" + tsHms.getSeconds()).slice(-2));
        //var buildPath = buildBasePath;
        //var tryTimes = 0, checkDir = false;
        //var publishPath;
        //do {
            //publishPath = path.isAbsolute(buildPath) ? buildPath : path.join(G.gameRoot, buildPath);
            //if (!fs.existsSync(publishPath)) {
                //checkDir = true;
                //break;
            //}
            //if (tryTimes++ > 30) break;
            //buildPath = buildBasePath + '_' + tryTimes;
        //} while (true);

        //if (!checkDir) {
            //G.log.trace('发布文件名定位异常。');
            //return;
        //}

        // 开始发布
        var publishResult = M.PROJECT.publishToPlatform(param ? param.platform : 'Browsers', publishPath, param.iconList, param.splash);
        if (typeof publishResult === 'string') {
            return { 'operRet' : false, 'reason' : publishResult };
        }

        // 打开这个文件夹
        var opener = require('opener');
        opener('file:' + publishPath);

        var ret = M.util.isLocalSocket(socket, M.COMMUNICATE.host) ? true : false;
        if ((!param || !param.platform || param.platform.toLowerCase() === 'browsers') && ret) {
            var relativePath = path.relative(G.gameRoot, publishPath);
            // 在游戏目录下才直接打开浏览器浏览
            if (!relativePath.startsWith('../')) {
                // 确定是本机，打开浏览器
                var host = M.COMMUNICATE.host;
                opener('http://' + host + ':' + M.COMMUNICATE.port + '/' + path.relative(G.gameRoot, publishPath) + '/StartGame.html');
            }
        }

        return { 'operRet' : true };
    }
});
