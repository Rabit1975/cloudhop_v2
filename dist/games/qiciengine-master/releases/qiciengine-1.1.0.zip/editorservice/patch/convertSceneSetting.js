/**
 * Created by lijh on Mar/18/2016.
 */

var MY_FLAG = 8;

var path = require('path');
var fs = require('fs-extra');
var chalk = require('chalk');

/**
 * 修复scene.setting中场景列表和入口场景格式，改为全路径
 */
var convert = function(dir, createFlag) {
    var projectSettingPath = path.join(dir, 'ProjectSetting/project.setting');
    var editorSettingPath  = path.join(dir, 'ProjectSetting/editor.setting');
    var sceneSettingPath   = path.join(dir, 'ProjectSetting/scene.setting');

    if (!fs.existsSync(projectSettingPath) ||
        !fs.existsSync(sceneSettingPath))
        return;

    var projectSetting;
    var sceneSetting;

    try {
        projectSetting = fs.readJsonSync(projectSettingPath, { throws : false });
        sceneSetting   = fs.readJsonSync(sceneSettingPath, { throws : false });
    }
    catch(e) {
        projectSetting = null;
        sceneSetting   = null;
    }
    if (projectSetting === null ||
        sceneSetting === null) {
        return;
    }
    
    var toolFlag = projectSetting.toolFlag || 0;
    if (toolFlag & (1 << MY_FLAG)) {
        // 处理过了
        return;
    }

    // 设置回写
    projectSetting.toolFlag = (toolFlag | (1 << MY_FLAG));
    G.load('filesystem/FsExpand').writeJsonSync(projectSettingPath, projectSetting);

    if (createFlag)
        return;

    // 将 editor.setting 中当前场景修改为完整路径
    if (fs.existsSync(editorSettingPath)) {
        var editorSetting = fs.readJsonSync(editorSettingPath, { throws : false });
        if (editorSetting) {
            var currScene = editorSetting.currScene;
            if (currScene && sceneSetting.scene[currScene]) {
                editorSetting.currScene = sceneSetting.scene[currScene].replace('.bin', '');

                 G.load('filesystem/FsExpand').writeJsonFileSync(editorSettingPath, editorSetting);
                 G.config.editor = editorSetting;
            }
        }
    }

    // 修改 scene.setting 中场景列表格式
    var entryScene = sceneSetting.entryScene;
    var entryScenePath = sceneSetting.scene[entryScene];
    var scenePaths = [];
    scenePaths.push(entryScenePath.replace('.bin', ''));
    for (var key in sceneSetting.scene) {
        if (key === entryScene)
            continue;

        scenePaths.push(sceneSetting.scene[key].replace('.bin', ''));
    }
    sceneSetting.scene = scenePaths;
    sceneSetting.entryScene = entryScenePath.replace('.bin', '');

    G.load('filesystem/FsExpand').writeJsonFileSync(sceneSettingPath, sceneSetting);
    G.config.scene = sceneSetting;
};

// 打开工程、切换工程的时候尝试 convert
G.emitter.on('preSwitchProject', function(createFlag) {
        convert(G.gameRoot, createFlag);
});

