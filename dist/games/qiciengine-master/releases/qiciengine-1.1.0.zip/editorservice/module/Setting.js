/**
 * @author wudm
 * copyright 2015 Qcplay All Rights Reserved.
 *
 * 配置
 */
var fs = require('fs-extra');
var path = require('path');

var clazz = function() {
};
clazz.prototype = {};
clazz.prototype.constructor = clazz;

// 保存配置
clazz.prototype.saveSetting = function(pairs) {
    // 获取配置信息
    var conf;
    try {
        conf = fs.readJsonSync(path.join(G.editorRoot, 'project.setting'), { throws : false });
    }
    catch(e) {
        conf = null;
    }

    if (!conf) conf = {};

    var keys = Object.keys(pairs);
    var idx = keys.length;
    while (idx--) {
        var key = keys[idx];
        switch (key) {
            case 'stateHistorySize':
                conf[key] = pairs[key] = this.getStateHistorySize(pairs[key]);
                break;
            default:
                conf[key] = pairs[key];
                break;
        }
    }

    // 保存
    G.load('filesystem/FsExpand').writeJsonSync(path.join(G.editorRoot, 'project.setting'), conf);

    return pairs;

};

// 查询配置
clazz.prototype.querySetting = function(key) {
    var conf;

    try {
        conf = fs.readJsonSync(path.join(G.editorRoot, 'project.setting'), {throws: false});
    }
    catch (e) {
        conf = null;
    }

    if (!conf) conf = {};

    conf.stateHistorySize = this.getStateHistorySize(conf.stateHistorySize);
    return key ? conf[key] : conf;
};

// 范围修正
clazz.prototype.getStateHistorySize = function(v) {
    if (v === undefined)
        // 没有值，取默认
        return 20;
    return Math.max(0, Math.min(30, parseInt(v)));
};

// 定义模块
G.defineModule('SETTING', clazz);
