/**
 * @author lijh
 * copyright 2015 Qcplay All Rights Reserved.
 */

/**
 * 粒子颜色控制器
 */
var Color = qc.ParticleSystem.Transitions.Color = function(particle) {
    this.particle = particle;
    this.particleSystem = particle.emitter.owner;
    this.time = particle.emitter.game.time;

    // 混合模式
    this.blendMode = Phaser.blendModes.NORMAL;

    // 粒子混合颜色
    this.colorTint = new qc.Color(0xFFFFFF);
    this.hexColor = this.colorTint.toNumber();

    // 粒子透明度
    this.alpha = this.originAlpha = 1;
};
Color.prototype.constructor = Color;

/**
 * 初始化方法
 */
Color.prototype.init = function() {
    this.alpha = this.originAlpha = qc.ParticleSystem.Util.getRandom(this.particleSystem.startAlpha);
    this.colorTint = new qc.Color(this.particleSystem.srcColorTint.toNumber());
    this.hexColor = this.colorTint.toNumber();
    this.blendMode = this.particleSystem.blendMode;
}

/**
 * 帧调度
 */
Color.prototype.update = function(elapsed, clampLife) {
    // 通过曲线刷新粒子颜色和透明度
    var t = clampLife;

    var from = this.particleSystem.srcColorTint.rgb;
    var to   = this.particleSystem.dstColorTint.rgb;
    if (from[0] !== to[0] || from[1] !== to[1] || from[2] !== to[2]) {
        var factor;
        if (this.particleSystem.enableColorCurve) {
            factor = this.particleSystem.colorCurve.evaluate(t);
        }
        else {
            factor = t;
        }

        if (from[0] !== to[0])
            this.colorTint.r = Phaser.Math.clamp(Math.round(from[0] + factor * (to[0] - from[0])), 0, 255);

        if (from[1] !== to[1])
            this.colorTint.g = Phaser.Math.clamp(Math.round(from[1] + factor * (to[1] - from[1])), 0, 255);

        if (from[2] !== to[2])
            this.colorTint.b = Phaser.Math.clamp(Math.round(from[2] + factor * (to[2] - from[2])), 0, 255);

        this.hexColor = this.colorTint.toNumber();
    }

    if (this.particleSystem.enableAlphaCurve) {
        var alphaFactor = this.particleSystem.alphaCurve.evaluate(t);
        this.alpha = this.originAlpha * alphaFactor;
    }
}
