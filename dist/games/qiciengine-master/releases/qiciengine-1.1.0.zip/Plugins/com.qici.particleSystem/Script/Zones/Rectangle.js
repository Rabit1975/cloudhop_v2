/**
 * @author lijh
 * copyright 2015 Qcplay All Rights Reserved.
 */

/**
 * 矩形发射区域
 */
var Rectangle = qc.ParticleSystem.Zones.Rectangle = function(width, height) {
    qc.ParticleSystem.Zones.Zone.call(this);

    var x = -width / 2;
    var y = -height / 2;
    this.geometry = new qc.Rectangle(x, y, width, height);
};
Rectangle.prototype = Object.create(qc.ParticleSystem.Zones.Zone.prototype);
Rectangle.prototype.constructor = Rectangle;

/**
 * 生成一个随机发射位置
 */
Rectangle.prototype.getRandom = function() {
    var t1 = Math.random();
    var t2 = Math.random();

    this._random.x = this.geometry.x + t1 * this.geometry.width;
    this._random.y = this.geometry.y + t2 * this.geometry.height;
}

